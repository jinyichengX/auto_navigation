// 图 2：安装俯仰角对地面/顶板可视距离与加权代价的影响
(function () {
  var style = getComputedStyle(document.documentElement);
  var accent = style.getPropertyValue('--accent').trim();
  var accent2 = style.getPropertyValue('--accent2').trim();
  var ink = style.getPropertyValue('--ink').trim();
  var muted = style.getPropertyValue('--muted').trim();
  var rule = style.getPropertyValue('--rule').trim();

  var hf = 1.5, hc = 2.0, wc = 0.85;
  var deg = Math.PI / 180;
  var xs = [], df = [], dc = [], J = [];
  for (var t = 0; t <= 28.4 + 1e-9; t += 1) {
    var thr = t * deg;
    var a = hf / Math.tan(7 * deg + thr);
    var b = hc / Math.tan(52 * deg - thr);
    xs.push(t.toFixed(0));
    df.push(+a.toFixed(2));
    dc.push(+b.toFixed(2));
    J.push(+(a + wc * b).toFixed(2));
  }

  var el = document.getElementById('chart-theta');
  if (!el) return;
  var chart = echarts.init(el, null, { renderer: 'svg' });

  chart.setOption({
    animation: false,
    color: [accent, accent2, muted],
    grid: { left: 54, right: 26, top: 46, bottom: 54 },
    legend: {
      top: 8,
      textStyle: { color: muted, fontFamily: 'GeistMono', fontSize: 11 },
      itemWidth: 18, itemHeight: 10
    },
    tooltip: {
      trigger: 'axis',
      appendToBody: true,
      valueFormatter: function (v) { return v + ' m'; },
      textStyle: { fontFamily: 'GeistMono', fontSize: 11 }
    },
    xAxis: {
      type: 'category',
      data: xs,
      name: '安装俯仰角 θ / °',
      nameLocation: 'middle',
      nameGap: 32,
      nameTextStyle: { color: muted, fontFamily: 'GeistMono', fontSize: 11 },
      axisLine: { lineStyle: { color: rule } },
      axisTick: { show: false },
      axisLabel: { color: muted, fontFamily: 'GeistMono', fontSize: 10, interval: 2 }
    },
    yAxis: {
      type: 'value',
      name: '可视距离 / m',
      nameTextStyle: { color: muted, fontFamily: 'GeistMono', fontSize: 11 },
      axisLine: { show: false },
      axisTick: { show: false },
      splitLine: { lineStyle: { color: rule, type: 'dashed' } },
      axisLabel: { color: muted, fontFamily: 'GeistMono', fontSize: 10 }
    },
    series: [
      {
        name: '地面盲区 r_blind',
        type: 'line',
        data: df,
        smooth: true,
        symbol: 'none',
        lineStyle: { width: 2.2 },
        areaStyle: { opacity: 0.08 }
      },
      {
        name: '顶板可视距离 d_c',
        type: 'line',
        data: dc,
        smooth: true,
        symbol: 'none',
        lineStyle: { width: 2.2 }
      },
      {
        name: '加权代价 J(θ)',
        type: 'line',
        data: J,
        smooth: true,
        symbol: 'none',
        lineStyle: { width: 1.8, type: 'dashed' },
        markPoint: {
          symbolSize: 40,
          data: [{
            name: 'θ*',
            coord: ['20', +(1.5 / Math.tan(27 * deg) + 0.85 * 2.0 / Math.tan(32 * deg)).toFixed(2)],
            itemStyle: { color: accent2 },
            label: {
              formatter: '20°',
              color: '#fff',
              fontFamily: 'GeistMono',
              fontSize: 10
            }
          }]
        },
        markLine: {
          silent: true,
          symbol: 'none',
          lineStyle: { color: accent2, type: 'dotted', width: 1.2 },
          label: { show: false },
          data: [{ xAxis: '20' }, { xAxis: '28' }]
        }
      }
    ]
  });

  window.addEventListener('resize', function () { chart.resize(); });
})();
